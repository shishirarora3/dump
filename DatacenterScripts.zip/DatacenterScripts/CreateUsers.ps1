param (
[string] $LiveInstance = "Consumer",
[int] $NumberOfUsers = 1,
[string] $Domain = "testdomain.com",
[switch] [bool] $Help = $false
);

function Print-usage($print)
{

if($print -eq $false)
{
	return;
}

Write-Host -ForegroundColor: Green "

SYNTAX
	CreateUsers.ps1 [-LiveInstance:Consumer/Business] [-NumberOfUsers:Number Of Users] [-Domain:Name of Domain and Organization] [-Help]

PARAMETERS

	-Help: 

		Displays this message.
	
	-LiveInstance: 

		Default is Consumer
		Consumer / Business
		Specifies whether the domain should be provisioned in Consumer or Business Instance		
		
	-NumberOfUsers:

		Default number of users is 1
		Number of users to be created between 1 - 100
		Users will be created as user1, user2 etc

	-Domain:

		Default domain name is testdomain.com
		Name to be used for domain and organization
			

EXAMPLES

	CreateOrg_BusinessConsumer.ps1
	CreateOrg_BusinessConsumer.ps1 -NumberOfUsers:3
	CreateOrg_BusinessConsumer.ps1 -LiveInstance:Consumer -NumberOfUsers:3
	CreateOrg_BusinessConsumer.ps1 -LiveInstance:Consumer -NumberOfUsers:3 -Domain:test.com
	CreateOrg_BusinessConsumer.ps1 -LiveInstance:Business -NumberOfUsers:3
	CreateOrg_BusinessConsumer.ps1 -LiveInstance:Business -NumberOfUsers:3 -Domain:test.com

NOTES

	Assumes Exchange is installed in System Drive $env:SystemDrive
"

exit;

}


function Create-users
{

# Global Parameters
# =================

$ProgIDs = @("ExchangeTest","EDU", "EDU", "FFDF", "FFDF", "FFDF", "MSIT", "MSIT", "MSOnline", "MSOnline", "MSOnline", "LawEnforcement")

$OfferIDs = @("2","IOwn", "OrgOwn", "Default", "ServiceDogfood", "ServiceDogfood_PF", "Default", "Default_PF", "BPOS_Basic", "BPOS_L", "BPOS_S", "Default")

$consumer = $true;

$adminSmtp = "admin" +"@" + $domain;

$filepath  = "$env:SystemDrive\Program Files\Microsoft\Exchange Test\Management\InitWLCDEnv.exe";

if($LiveInstance -eq "Business" -or $LiveInstance -eq "business")
{
	$Consumer = $false;
}


# Create Consumer tenant and users
# ================================

if($Consumer -eq $true)
{
	Write-Host -ForegroundColor Green "Reserving domain $domain in Consumer Instance"

	try
	{

	& $filepath /r:$domain

	Write-Host -ForegroundColor Green "Creating organization $domain with administrator $adminsmtp"

	New-Organization -Name $domain -DomainName $domain -ProgramId:$ProgIDs[0] -OfferId:$OfferIDs[0] -Location:UnitedStates -Administrator:$adminsmtp

	Write-Host -ForegroundColor Green  "Creating $NumberOfUsers consumer users"

	for ($i=0; $i -lt $NumberOfUsers; $i++)
	{

		$user = "user" + $i;
		$userSmtp = $user + "@" + $domain;

		Write-Host -ForegroundColor Green "Creating Consumer User "+ $usersmtp;

		New-Mailbox -Name $user -WindowsLiveID $userSmtp -Organization $domain -Password (ConvertTo-SecureString 'J$p1ter' -AsPlainText -force)

		ExchangeOneBoxCommandLine /F:$userSmtp 
	}

	}
	catch
	{

		Write-Error "Error Occured while performing one of the operations required to create users"
		Write-Error "Script did not succeed"
		exit;
	}

}

# Create Business tenant and users
# ================================

else
{

	Write-Host -ForegroundColor Green "Reserving domain $domain in Business Instance"

	try
	{

	ExchangeOneBoxCommandLine.exe /IP:WLIDB /ReserveNamespace:$domain

	ExchangeOneBoxCommandLine.exe /IP:WLIDB /GrantNamespaceAdminRestrictedRoleToExchange:$domain

	ExchangeOneBoxCommandLine.exe /IP:WLIDB /AddCredential:$adminSmtp

	Write-Host -ForegroundColor Green "Creating organization $domain with administrator $adminsmtp"

	New-Organization -IsDatacenter -Name $domain -ProgramId:$ProgIDs[10] -OfferId:$OfferIDs[10] -Location:UnitedStates -DomainName $domain -Administrator:$adminSmtp -LiveIdInstanceType Business


	Write-Host -ForegroundColor Green "Creating $NumberOfUsers Business Users"

	for ($i=0; $i -lt $NumberOfUsers; $i++)
	{

		$user = "user" + $i;
		$userSmtp = $user + "@" + $domain;

		Write-Host -ForegroundColor Green "Creating Business user $userSmtp"

		New-Mailbox -Name $user -WindowsLiveID $userSmtp -Organization $domain -Password (ConvertTo-SecureString 'J$p1ter' -AsPlainText -force)

		ExchangeOneBoxCommandLine /F:$userSmtp /IP:WLIDB

	}

	}
	catch
	{

		Write-Error "Error Occured while performing one of the operations required to create users"
		Write-Error "Script did not succeed"
		exit;
	}

}

}


# Actual Code starts here
# =======================

Print-Usage $help


if($NumberOfUsers -gt 100 -or $NumberOfUsers -lt 0)
{

	Write-Error "Number of users should be between 1 - 100"

}


Create-Users

if($? -eq $true)
{

Write-Host
Write-Host -ForegroundColor Green "In the event that the script did not report other errors, following users were created:"

Write-Host -ForegroundColor Green "Live Id Instance chosen $LiveInstance"

Write-Host -ForegroundColor Green "Created Users:"

for($i=0; $i -lt $NumberOfUsers; $i++)
{

	$user = "user" + $i;

	$userSmtp = $user + "@" + $domain;

	Write-Host $userSmtp		
}

}