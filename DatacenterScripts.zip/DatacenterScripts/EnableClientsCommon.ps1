# Enable the EnableClientsCommonModule
function EnableClientsCommonModule
{
    $owaWebConfigFolder = $caspath  + "owa\"
    $owaWebConfigPath = $owaWebConfigFolder + "web.config"
		
    $owaWebConfigPathCheck = (Get-Item $owaWebConfigPath).FullName
    if (!$owaWebConfigPathCheck) { Log "no OWA web.config is found"; return }

    $xmlDocument = New-Object System.Xml.XmlDocument;
    $xmlDocument.Load($owaWebConfigPath);
    
    $configurationRoot = "configuration/location";

    $clientsCommonModuleNode = $xmlDocument.SelectSingleNode($configurationRoot + "/system.webServer/modules/add[@name='ClientsCommonModule']");

    $clientsCommonModuleNodeType = "Microsoft.Exchange.Clients.Common.ClientsCommonModule";

    if ($clientsCommonModuleNode -eq $null)
    {
        # WriteLog "Adding clients common module to Web.config file" "Warning";
        [System.Xml.XmlNode] $clientsCommonModuleNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "add", $null);

        AddXmlAttribute $xmlDocument $clientsCommonModuleNode "name" "ClientsCommonModule";
        AddXmlAttribute $xmlDocument $clientsCommonModuleNode "type" $clientsCommonModuleNodeType;

        $modulesNode = $xmlDocument.SelectSingleNode($configurationRoot + "/system.webServer/modules");
        $owa2ModuleNode = $xmlDocument.SelectSingleNode($configurationRoot + "/system.webServer/modules/add[@name='Owa2Module']");

        $temp = $modulesNode.PrependChild($clientsCommonModuleNode);
    }
}

$caspath = (get-itemproperty HKLM:\SOFTWARE\Microsoft\ExchangeServer\v15\Setup).MsiInstallPath + "ClientAccess\"

EnableClientsCommonModule