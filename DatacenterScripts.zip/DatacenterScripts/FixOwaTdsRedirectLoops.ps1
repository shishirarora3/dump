<#
    .SYNOPSIS
    Fixes the redirect loops issue when attempting to use OWA on Datacenter Basic TDS's.
    This issue is caused by a folder incorrectly being set up when TDS's are created.
    
    .DESCRIPTION
    Same as synopsis above.
    
    .EXAMPLE 
    FixOwaTdsRedirectLoops.ps1
    
    .NOTES
    Run this cmdlet in the TDS you want to fix. May need to restart the browser to see OWA load correctly.
#>

$path = 'C:\Program Files\Microsoft\Exchange Server\V15\FrontEnd\HttpProxy\owa\auth\';
$folders = gci $path -Directory | select Name;

foreach ($folderName in $folders.Name)
{
    if ($folderName -like '15.20.*')
    {
        $buildFolderPath = $path + $folderName;
        $buildFolderNewName = $folderName + '_Old';
        $currentFolderPath = $path + 'Current';
        Rename-Item -Path $buildFolderPath -NewName $buildFolderNewName;
        Copy-Item $currentFolderPath $buildFolderPath -Recurse;
        return;
    }
}
