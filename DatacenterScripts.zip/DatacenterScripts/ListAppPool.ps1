﻿Param 
(
    [Parameter(Mandatory=$false)]
    [string]
    $appPool = 'MSExchangeOWAAppPool'
)

C:\Windows\System32\inetsrv\appcmd list wps /apppool.name:$appPool 