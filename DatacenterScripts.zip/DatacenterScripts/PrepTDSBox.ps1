﻿param (
[switch] $LaunchRascal = $false,
[switch] $InstallFiddler = $false,
[switch] $Shadow = $false,
[switch] $OpenIdConnect = $false,
[switch] $LaunchExoConfigDir = $false,
[switch] $OwaPid = $false,
[switch] $BounceOwa = $false
);

if ($OwaPid)
{
    Push-Location "$env:SystemRoot\System32\inetsrv\"
    .\appcmd.exe list wp | findstr /i owa
    Pop-Location
    exit
}

if ($BounceOwa)
{
    Push-Location "$env:SystemRoot\System32\inetsrv\"
    .\appcmd recycle apppool /apppool.name:MSExchangeOWAAppPool
    Pop-Location
    exit
}   

$localUserFolder = "$env:SystemDrive\users\$env:USERNAME\"
$dcScriptFolder = Get-Location
$exchangeDir = "$env:ProgramFiles\Microsoft\Exchange Server\V15"

while (-Not (Test-Path $dcScriptFolder))
{
    # This needs to happen first so that creds can be prompted
    Write-Host "You need to logon to $dcScriptFolder in Explorer to pass your Redmond\account creds for this script to work. The directory has been copied to the clipboard."
    $dcScriptFolder | clip
    Explorer
    Read-Host 'Press <enter> when done'
}

Write-Host 'Copy Files to Desktop'
Push-Location "$localUserFolder\Desktop"
Copy-Item "$dcScriptFolder\AddConsumerUser.ps1" .\ -Force
Copy-Item "$dcScriptFolder\CreateUsers.ps1" .\ -Force
Copy-Item "$dcScriptFolder\CreateUsersCommand.txt" .\ -Force
Pop-Location

Write-Host 'Creating OWA Bookmarks in Chrome'
$chromeSettingsPath = "$localUserFolder\AppData\Local\Google\Chrome\User Data\Default\"
if (-not (Test-Path $chromeSettingsPath))
{
    mkdir $chromeSettingsPath
}
$chromeBookMarksFilePath = "$chromeSettingsPath\Bookmarks"
Copy-Item "$dcScriptFolder\Bookmarks" "$chromeBookMarksFilePath" -Force

if ($InstallFiddler)
{
    Write-Host 'Installing Fiddler'
    Start-Process "$dcScriptFolder\fiddlersetup.exe"
}

if ($LaunchRascal)
{
    Write-Host 'Launching Rascal'
    Start-Process "$env:SystemDrive\Rascal\Rascal.exe"
}

if ($LaunchExoConfigDir)
{
    Explorer "$exchangeDir\Config"
}

Write-Host 'Stopping Health Services'
Stop-Service MSExchangeHMRecovery
Stop-Service MSExchangeHM 

Set-Service MSExchangeHMRecovery -StartupType Disabled
Set-Service MSExchangeHM -StartupType Disabled

if ($Shadow)
{
    Write-Host 'Making sure snapin is installed'
    Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn
    if (!$?)
    {
        exit
    }

    Write-Host 'Configuring MRS'
    New-ExchangeSettings MRS -Confirm:$false
	Set-ExchangeSettings MRS -UpdateSetting -ConfigName IgnoreHealthMonitor -ConfigValue $true -Confirm:$false -Reason "test" 
	Set-ExchangeSettings MRS -UpdateSetting -GroupName default -ConfigName "AllowedUserInactivityInterval" -ConfigValue "00:00:00" –reason "disable inactive user optimization" -Confirm:$false

    Set-ExchangeSettings MRS -UpdateSetting -GroupName default -ConfigName "IsAdvancedShadowValidationEnabled" -ConfigValue "false" –reason "advanced validaiton is buggy" -Confirm:$false
}

if ($Shadow -or $OpenIdConnect)
{
    Push-Location ..\OAuth2\PS1
    
    Write-Host 'Setting up datacenter for OIDC'
    .\setupdatacenter.ps1

    Write-Host 'Creating Partner Application'
    .\CreatePartnerApplication.ps1

    Write-Host 'Resetting IIS and MRS services'
    Restart-Service MSExchangeMailboxReplication
    iisreset

    Pop-Location
}