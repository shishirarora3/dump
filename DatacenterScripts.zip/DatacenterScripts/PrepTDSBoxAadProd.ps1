﻿param (
[switch] $LaunchRascal = $false,
[switch] $InstallFiddler = $false,
[switch] $Shadow = $false,
[switch] $OpenIdConnect = $false,
[switch] $LaunchExoConfigDir = $false,
[switch] $OwaPid = $false,
[switch] $BounceOwa = $false
);

if ($OwaPid)
{
    Push-Location "$env:SystemRoot\System32\inetsrv\"
    .\appcmd.exe list wp | findstr /i owa
    Pop-Location
    exit
}

if ($BounceOwa)
{
    Push-Location "$env:SystemRoot\System32\inetsrv\"
    .\appcmd recycle apppool /apppool.name:MSExchangeOWAAppPool
    Pop-Location
    exit
}   

$localUserFolder = "$env:SystemDrive\users\$env:USERNAME\"
$dcScriptFolder = Get-Location
$exchangeDir = "$env:ProgramFiles\Microsoft\Exchange Server\V15"

Write-Host $dcScriptFolder
Write-Host 'Copy Files to Desktop'
Push-Location "$localUserFolder\Desktop"
Copy-Item "$dcScriptFolder\AddConsumerUser.ps1" .\ -Force
Copy-Item "$dcScriptFolder\CreateUsers.ps1" .\ -Force
Copy-Item "$dcScriptFolder\CreateUsersCommand.txt" .\ -Force
Pop-Location

Write-Host 'Creating OWA Bookmarks in Chrome'
$chromeSettingsPath = "$localUserFolder\AppData\Local\Google\Chrome\User Data\Default\"
if (-not (Test-Path $chromeSettingsPath))
{
    mkdir $chromeSettingsPath
}
$chromeBookMarksFilePath = "$chromeSettingsPath\Bookmarks"
Copy-Item "$dcScriptFolder\Bookmarks" "$chromeBookMarksFilePath" -Force

if ($InstallFiddler)
{
    $fpath = "$dcScriptFolder\fiddler4setup.exe"
    Write-Host  $fpath
    Write-Host "Installing Fiddler $dcScriptFolder\fiddler4setup.exe"
    Start-Process "$dcScriptFolder\fiddler4setup.exe"
}

if ($LaunchRascal)
{
    Write-Host 'Launching Rascal'
    Start-Process "$env:SystemDrive\Rascal\Rascal.exe"
}

if ($LaunchExoConfigDir)
{
    Explorer "$exchangeDir\Config"
}

Write-Host 'Stopping Health Services'
Stop-Service MSExchangeHMRecovery
Stop-Service MSExchangeHM 

Set-Service MSExchangeHMRecovery -StartupType Disabled
Set-Service MSExchangeHM -StartupType Disabled

if ($Shadow)
{
    Write-Host 'Making sure snapin is installed'
    Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn
    if (!$?)
    {
        exit
    }

    Write-Host 'Configuring MRS'
    New-ExchangeSettings MRS -Confirm:$false
	Set-ExchangeSettings MRS -UpdateSetting -ConfigName IgnoreHealthMonitor -ConfigValue $true -Confirm:$false -Reason "test" 
	Set-ExchangeSettings MRS -UpdateSetting -GroupName default -ConfigName "AllowedUserInactivityInterval" -ConfigValue "00:00:00" –reason "disable inactive user optimization" -Confirm:$false

    Set-ExchangeSettings MRS -UpdateSetting -GroupName default -ConfigName "IsAdvancedShadowValidationEnabled" -ConfigValue "false" –reason "advanced validaiton is buggy" -Confirm:$false
}

if ($Shadow -or $OpenIdConnect)
{    
    Write-Host 'Setting up datacenter for OIDC'
  	$AADTenantDomain = "owaauth.onmicrosoft.com"
	$adminUPN = "ravijai@owaauth.onmicrosoft.com"
	$instanceType = "Business"
	$tenantExternalDirectoryObjectId = "05f23239-ba9d-452b-83f5-f2cf321583d0"
	$adminPUID = "10033FFFA2E6D75D"
    
	New-Organization -name $AADTenantDomain -DomainName $AADTenantDomain -Administrator $adminUPN -ProgramId ExchangeTest -OfferId 2 -Location US -LiveIdInstanceType $instanceType -AuthenticationType Managed -ExternalDirectoryOrganizationId $tenantExternalDirectoryObjectId -AdministratorNetID $adminPUID -IsDatacenter

	$userUPN = "user1@owaauth.onmicrosoft.com"
	$userName = "User 1"
	$userPuid = "1003BFFDA2E74D57"
	$userExternalDirectoryObjectId = "00ebf1d9-d9b6-4996-86e2-10905b70854b"
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId

	$userUPN = "user2@owaauth.onmicrosoft.com"
	$userName = "User 2"
	$userPuid = "10037FFEA2E7CD0A"
	$userExternalDirectoryObjectId = "f538e592-b735-48ab-8635-3e1fa6f23feb"	
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId

	$userUPN = "user6@owaauth.onmicrosoft.com"
	$userName = "User 6"
	$userPuid = "10032000CDF614AF"
	$userExternalDirectoryObjectId = "6e741263-dbf7-4532-b25f-477b0fe2c0bb"	
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId
	
    	Remove-AuthServer EvoSts -Confirm:$false -ErrorAction SilentlyContinue
	New-AuthServer -Type AzureAD -Name EvoStsProd -AuthMetadataUrl https://login.microsoftonline.com/common/federationmetadata/2007-06/federationmetadata.xml -TrustAnySSLCertificate
	Set-AuthServer EvoStsProd -IsDefaultAuthorizationEndpoint $true -ErrorAction SilentlyContinue

    Write-Host 'Update openidconnect flight and auth settings'


        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
        Install-Module -Scope CurrentUser PsIni -Force
        $oidcFlightPath = "$exchangeDir\Config\OpenIdConnect.flight.ini"
        $authSettingsPath = "$exchangeDir\Config\Auth.settings.ini"
        $oidcFlights = Get-IniContent $oidcFlightPath
        $oidcFlights["OpenIdConnect"]["Enabled"] = "true"
        $oidcFlights["OpenIdConnect"]["Enabled&test:true"] = "true"
        $authSettings = Get-IniContent $authSettingsPath
        $authSettings["OpenIdConnectAuthentication"]["AuthServiceHostname&test:true"] = "https://login.microsoftonline.com/"
        Out-IniFile -InputObject $authSettings -FilePath $authSettingsPath -Force
        Out-IniFile -InputObject $oidcFlights -FilePath $oidcFlightPath -Force


    Write-Host 'Resetting IIS and MRS services'
    Restart-Service MSExchangeMailboxReplication
    iisreset

    Pop-Location
}