﻿param (
[switch] $LaunchRascal = $false,
[switch] $InstallFiddler = $false,
[switch] $Shadow = $false,
[switch] $OpenIdConnect = $false,
[switch] $LaunchExoConfigDir = $false,
[switch] $OwaPid = $false,
[switch] $BounceOwa = $false
);

if ($OwaPid)
{
    Push-Location "$env:SystemRoot\System32\inetsrv\"
    .\appcmd.exe list wp | findstr /i owa
    Pop-Location
    exit
}

if ($BounceOwa)
{
    Push-Location "$env:SystemRoot\System32\inetsrv\"
    .\appcmd recycle apppool /apppool.name:MSExchangeOWAAppPool
    Pop-Location
    exit
}   

$localUserFolder = "$env:SystemDrive\users\$env:USERNAME\"
$dcScriptFolder = Get-Location
$exchangeDir = "$env:ProgramFiles\Microsoft\Exchange Server\V15"

while (-Not (Test-Path $dcScriptFolder))
{
    # This needs to happen first so that creds can be prompted
    Write-Host "You need to logon to $dcScriptFolder in Explorer to pass your Redmond\account creds for this script to work. The directory has been copied to the clipboard."
    $dcScriptFolder | clip
    Explorer
    Read-Host 'Press <enter> when done'
}

Write-Host 'Copy Files to Desktop'
Push-Location "$localUserFolder\Desktop"
Copy-Item "$dcScriptFolder\AddConsumerUser.ps1" .\ -Force
Copy-Item "$dcScriptFolder\CreateUsers.ps1" .\ -Force
#Copy-Item "$dcScriptFolder\CreateUsersCommand.txt" .\ -Force
Pop-Location

Write-Host 'Creating OWA Bookmarks in Chrome'
$chromeSettingsPath = "$localUserFolder\AppData\Local\Google\Chrome\User Data\Default\"
if (-not (Test-Path $chromeSettingsPath))
{
    mkdir $chromeSettingsPath
}
$chromeBookMarksFilePath = "$chromeSettingsPath\Bookmarks"
Copy-Item "$dcScriptFolder\Bookmarks" "$chromeBookMarksFilePath" -Force

if ($InstallFiddler)
{
    Write-Host 'Installing Fiddler'
    Start-Process "$dcScriptFolder\fiddlersetup.exe"
}

if ($LaunchRascal)
{
    Write-Host 'Launching Rascal'
    Start-Process "$env:SystemDrive\Rascal\Rascal.exe"
}

if ($LaunchExoConfigDir)
{
    Explorer "$exchangeDir\Config"
}

Write-Host 'Stopping Health Services'
Stop-Service MSExchangeHMRecovery
Stop-Service MSExchangeHM 

Set-Service MSExchangeHMRecovery -StartupType Disabled
Set-Service MSExchangeHM -StartupType Disabled

if ($Shadow)
{
    Write-Host 'Making sure snapin is installed'
    Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn
    if (!$?)
    {
        exit
    }

    Write-Host 'Configuring MRS'                                                                                                                                                                                                E:\DATA\TOOLS.DONE\EXCHANGE\SSM\ravijai\PrepTDSBoxV2SSM.ps1
    New-ExchangeSettings MRS -Confirm:$false
	Set-ExchangeSettings MRS -UpdateSetting -ConfigName IgnoreHealthMonitor -ConfigValue $true -Confirm:$false -Reason "test" 
	Set-ExchangeSettings MRS -UpdateSetting -GroupName default -ConfigName "AllowedUserInactivityInterval" -ConfigValue "00:00:00" –reason "disable inactive user optimization" -Confirm:$false

    Set-ExchangeSettings MRS -UpdateSetting -GroupName default -ConfigName "IsAdvancedShadowValidationEnabled" -ConfigValue "false" –reason "advanced validaiton is buggy" -Confirm:$false
}

if ($Shadow -or $OpenIdConnect)
{    
    Write-Host 'Setting up datacenter for OIDC'
  	$AADTenantDomain = "owaauth.onmicrosoft.com"
	$adminUPN = "ravijai@owaauth.onmicrosoft.com"
	$instanceType = "Business"
	$tenantExternalDirectoryObjectId = "05f23239-ba9d-452b-83f5-f2cf321583d0"
	$adminPUID = "10033FFFA2E6D75D"
    
	New-Organization -name $AADTenantDomain -DomainName $AADTenantDomain -Administrator $adminUPN -ProgramId ExchangeTest -OfferId 2 -Location US -LiveIdInstanceType $instanceType -AuthenticationType Managed -ExternalDirectoryOrganizationId $tenantExternalDirectoryObjectId -AdministratorNetID $adminPUID -IsDatacenter

	$userUPN = "user1@owaauth.onmicrosoft.com"
	$userName = "User 1"
	$userPuid = "1003BFFDA2E74D57"
	$userExternalDirectoryObjectId = "00ebf1d9-d9b6-4996-86e2-10905b70854b"
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId

	$userUPN = "user2@owaauth.onmicrosoft.com"
	$userName = "User 2"
	$userPuid = "10037FFEA2E7CD0A"
	$userExternalDirectoryObjectId = "f538e592-b735-48ab-8635-3e1fa6f23feb"
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId
	

	$userUPN = "user3@owaauth.onmicrosoft.com"
	$userName = "User 3"
	$userPuid = "10033FFFA302C887"
	$userExternalDirectoryObjectId = "489d214a-6222-4604-9fa8-855dc16165ba"
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId

	$userUPN = "user4@owaauth.onmicrosoft.com"
	$userName = "User 4"
	$userPuid = "10037FFEA2E7CD1E"
	$userExternalDirectoryObjectId = "6e276873-2b2b-4455-9f8f-5e96b7473c53"
	New-Mailbox -Organization $AADTenantDomain -WindowsLiveID $userUPN -Name $userName -UseExistingLiveId -NetID $userPuid -ExternalDirectoryObjectId $userExternalDirectoryObjectId


	New-AuthServer -Type AzureAD -Name EvoStsProd -AuthMetadataUrl https://login.microsoftonline.com/common/federationmetadata/2007-06/federationmetadata.xml -TrustAnySSLCertificate
	Set-AuthServer EvoStsProd -IsDefaultAuthorizationEndpoint $true -ErrorAction SilentlyContinue

    Write-Host 'Resetting IIS and MRS services'
    Restart-Service MSExchangeMailboxReplication
    iisreset

    Pop-Location
}