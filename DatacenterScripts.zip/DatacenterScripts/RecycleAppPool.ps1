﻿Param 
(
    [Parameter(Mandatory=$false)]
    [string]
    $appPool = 'MSExchangeOWAAppPool'
)

C:\Windows\System32\inetsrv\appcmd recycle apppool /apppool.name:$appPool