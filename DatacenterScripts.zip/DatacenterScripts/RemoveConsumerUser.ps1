﻿param (
[string] $UserNameNoDomain = $(throw "UserName parameter required"),
[string] $Domain = 'outlook-int.com',
[string] $TenantName = 'consumerorg.com',
[string] $databaseName = $null,
[switch] $JitProvisionAccount = $false,
[switch] $PrimaryInHotmail = $false,
[switch] $NoExo = $false
);

if ($JitProvisionAccount -and ($PrimaryInHotmail -or $NoExo))
{
    throw 'Cannot JIT provision in Hotmail'
}

if ($NoExo -and $PrimaryInHotmail)
{
    throw 'NoEXO implies primary in hotmail. Don not use both flags'
}

pushd .

Write-Host 'Making sure snapin is installed'
Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn 
if (!$?)
{
    exit
}

cd "$env:ProgramFiles\Microsoft\Exchange Test\Tools" 
$smtp = $UserNameNoDomain + '@' + $Domain
Write-Host "Creating user MSA $smtp"
$cred = $smtp + ':J$p1ter'
$addedCred = .\ExchangeOneBoxCommandLine.exe /AddCredential:$cred /IP:WLID

Write-Host Parsing PUID from MSA response
$puid = $null
$cid = $null
if ($addedCred -ne $null)
{
    # The standard output from \ExchangeOneBoxCommandLine.exe /AddCredential looks something like:
        # ExchangeOneBoxCommandLine.exe
        # Tool to configure WLID OneBox.
        #
        # Initializing Configuration for Windows Live...
        # WLID OneBox at 10.197.13.108::nexus.passport-int.com
        # Adding Credential testthis111@outlook-int.com:J@p1ter123...
        # Added Credential: testthis111@outlook-int.com[00030000800FD0BA][3a522d67817bcd44]
        # Leaving Configuration initialized for Windows Live.
    #
    # The above string array has 8 items. At position 6 we see the username attached to the PUID
    if ($addedCred.Length -eq 8 -and $addedCred[6] -ne $null)
    {
        $puidIndex = $addedCred[6].IndexOf('[') + 1
        $closingBracketIndex = $addedCred[6].IndexOf(']')
        if ($puidIndex -gt -1 -and $closingBracketIndex -gt $puidIndex)
        {            
            $puid = $addedCred[6].Substring($puidIndex, $closingBracketIndex - $puidIndex)
            
            #The CID follows after PUID
            $remainderWithCid = $addedCred[6].Substring($closingBracketIndex + 1)
            $cidIndex = $remainderWithCid.IndexOf('[') + 1
            $cidClosingBracketIndex = $remainderWithCid.IndexOf(']')
            if ($cidIndex -gt -1 -and $cidClosingBracketIndex -gt $cidIndex)
            {
                $cid = $remainderWithCid.Substring($cidIndex, $cidClosingBracketIndex - $cidIndex)
            }            
        }
    }
}

if ($puid -eq $null)
{
    popd
    throw "Cannot find puid for user $smtp"
}
Write-Host "Using PUID $puid for $smtp"

if([String]::IsNullOrEmpty($databaseName))
{
    $database = Get-MailboxDatabase | ?{ $_.IsExcludedFromProvisioning -eq $false } | select -first 1    
}
else
{
    $database = Get-MailboxDatabase $databaseName | ?{ $_.IsExcludedFromProvisioning -eq $false }   
}

if ($database -eq $null)
    {
        popd
        throw 'Could not find mailbox database'
    }

if ($JitProvisionAccount)
{
    Write-Host 'JIT provisioning requested. Account will be created on first logon'
}
elseif ($PrimaryInHotmail -or $NoExo)
{
    if (-not (Test-Path ".\mcli"))
    {
        Write-Host "Copying MCLI tools down"
        mkdir ".\mcli"
        pushd .\mcli
        Copy-Item "\\mc2\Scratch2\swamipat\exchg\SqlMservMCLI-EXO\mcli\*" .\ -Recurse
        
        if (!$?)
        {
            popd
            popd 
            throw 'Could not create copy MCLI tools.'
        }        
    }
    else
    {
        pushd .\mcli
    }
    
    "Provisioning the user primarily in Hotmail"
    .\MCLI.exe /i 127.0.0.1 /r 0 a "($puid)" "1.2.3.4 555"
    .\MCLI.exe /i  127.0.0.1  /r 0 aa $smtp "($puid)"
    popd
    
    if ($PrimaryInHotmail)
    {
        Write-Host "Create the secondary EXO mailbox for $smtp"
        New-ConsumerMailbox -EmailAddresses $smtp -WindowsLiveID $puid -MakeExoSecondary -Database $database.Name -Languages @{Add="en-US"} -CID $cid
        
        if (!$?)
        {
            popd
            throw 'Could not create secondary mailbox.'
        }
    }
}
else
{
    Write-Host "Create the mailbox for $smtp"
    New-ConsumerMailbox -EmailAddresses $smtp -WindowsLiveID $puid -MakeExoPrimary -Database $database.Name -Languages @{Add="en-US"} -CID $cid

    if (!$?)
    {
        popd
        throw 'Could not create consumer mailbox.'
    }
}

Write-Host "Created consumer account $smtp"

popd