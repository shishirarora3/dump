﻿
function ConfigureApppool($AppList = @(), $Default = $false)
{
    $appCmd = "$env:SystemRoot\system32\inetsrv\appcmd.exe"
    $AppPoolList = @{};
    $AppPoolList.Add("/API".ToLower(), ("/API", "MSExchangeRestFrontEndAppPool"))
    $AppPoolList.Add("/EWS".ToLower(), ("/EWS", "MSExchangeServicesAppPool"))
    $AppPoolList.Add("/MailboxDelivery".ToLower(), ("/MailboxDelivery", "MSExchangeMailboxDeliveryFrontEndAppPool"))
    $AppPoolList.Add("/Delve".ToLower(), ("/Delve", "MSExchangeMicroServiceAppPool"))
    $AppPoolList.Add("/DelveApi".ToLower(), ("/DelveApi", "MSExchangeMicroServiceAppPool"))
    $AppPoolList.Add("/MicroService".ToLower(), ("/MicroService", "MSExchangeMicroServiceAppPool"))
    $AppPoolList.Add("/owa".ToLower(), ("/owa", "MSExchangeOWAAppPool"))
    $AppPoolList.Add("/owa/Calendar".ToLower(), ("/owa/Calendar", "MSExchangeOWACalendarAppPool"))
    $AppPoolList.Add("/owa/oma".ToLower(), ("/owa/oma", "MSExchangeOWAAppPool"))
    $AppPoolList.Add("/Microsoft-Server-ActiveSync".ToLower(), ("/Microsoft-Server-ActiveSync", "MSExchangeSyncAppPool"))
    $AppPoolList.Add("/mapi".ToLower(), ("/mapi", "MSExchangeMapiFrontEndAppPool"))
    $AppPoolList.Add("/Rpc".ToLower(), ("/Rpc", "MSExchangeRpcProxyFrontEndAppPool"))
    $AppPoolList.Add("/ecp".ToLower(), ("/ecp", "MSExchangeECPAppPool"))
    $AppPoolList.Add("/ecp/ReportingWebService".ToLower(), ("/ecp/ReportingWebService", "MSExchangeReportingWebServiceAppPool"))
    $AppPoolList.Add("/Autodiscover".ToLower(), ("/Autodiscover", "MSExchangeAutodiscoverAppPool"))
    $AppPoolList.Add("/OAB".ToLower(), ("/OAB", "MSExchangeOABAppPool"))
    $AppPoolList.Add("/PowerShell".ToLower(), ("/PowerShell", "MSExchangePowerShellFrontEndAppPool"))
    $AppPoolList.Add("/PowerShell-LiveID".ToLower(), ("/PowerShell-LiveID", "MSExchangePowerShellLiveIDFrontEndAppPool"))
    $AppPoolList.Add("/Psws".ToLower(), ("/Psws", "MSExchangePswsFrontEndAppPool"))
    $AppPoolList.Add("/PushNotifications".ToLower(), ("/PushNotifications", "MSExchangePushNotificationsAppPool"))
    $AppPoolList.Add("/O365SuiteService".ToLower(), ("/O365SuiteService", "MSExchangeO365SuiteServiceAppPool"))
    $AppPoolList.Add("/ComplianceService".ToLower(), ("/ComplianceService", "MSExchangeComplianceServiceFrontEndAppPool"))
    $AppPoolList.Add("/xrop".ToLower(), ("/xrop", "MSExchangeXRopAppPool"))
    $AppPoolList.Add("/Encryption".ToLower(), ("/Encryption", "MSExchangeEncryptionAppPool"))
    $AppPoolList.Add("/OutlookService".ToLower(), ("/OutlookService", "MSExchangeOutlookServiceAppPool"))
    $AppPoolList.Add("/Sapi".ToLower(), ("/Sapi", "MSExchangeSyncAppPool"))
    $AppPoolList.Add("/routingupdates".ToLower(), ("/routingupdates", "MSExchangeRoutingUpdatesAppPool"))

    Write-Verbose "Listing all app configuration before changing it"
    $currentList = & $appCmd list app | Out-String
    Write-Verbose ($currentList)

    Write-Host "Validating specified apps have an app pool mapping defined" -foregroundcolor green

    foreach ($App in $AppList)
    {
        if (!$AppPoolList.ContainsKey($App.ToLower()))
        {
            Write-Error "App pool mapping must be defined in order to be able to change the configuration for this app $($App)"
            $AppPoolList
            throw "Unknown app, the app must have a app pool mapping defined"
        }
    }

    if ($AppList.Count -gt 0)
    {
        Write-Host "Changing specified apps to use the new app pool Default:$($Default)" -foregroundcolor green

        foreach ($App in $AppList)
        {
            $AppName = "Default Web Site" + $AppPoolList[$App.ToLower()][0]
            $AppPoolName = "DefaultAppPool"

            if (!$Default)
            {
                $AppPoolName = $AppPoolList[$App.ToLower()][1]
            }

            Write-Host "Querying $($AppName) configuration"
            & $appCmd list app $AppName

            Write-Host "Configuring $($AppName) to run in $($AppPoolName)"
            & $appCmd set app $AppName /applicationPool:$AppPoolName

            if ($Default)
            {
                $AppPoolName = $AppPoolList[$App.ToLower()][1]
                Write-Host "Recycling $($AppPoolName)"
                & $appCmd recycle apppool /apppool.name:$AppPoolName
            }
        }
    }
    else
    {
        if ($Default)
        {
            Write-Error "App list must be specified in order to be able to change the configuration to default"
            $AppList
            throw "Missing app list for default configuration"
        }
    
        Write-Host "Changing all apps to use their original app pools" -foregroundcolor green

        foreach ($AppPoolMapping in $AppPoolList.Values)
        {
            $AppName = "Default Web Site" + $AppPoolMapping[0];
            $AppPoolName = $AppPoolMapping[1]
 
            Write-Host "Querying $($AppName) configuration"
            & $appCmd list app $AppName

            Write-Host "Configuring $($AppName) to run in $($AppPoolName)"
            & $appCmd set app $AppName /applicationPool:$AppPoolName
        }
    }

    if (!$Default)
    {
        $AppPoolName = "DefaultAppPool"
        Write-Host "Recycling $($AppPoolName)"
        & $appCmd recycle apppool /apppool.name:$AppPoolName
    }

    Write-Verbose "Listing all app configuration after the change"
    $resultList = & $appCmd list app | Out-String
    Write-Verbose ($resultList)

    Write-Verbose "Recycling MsExchangeHealthManager"
    Restart-Service MSExchangeHM -force
}

Import-Module WebAdministration
$defaultSites = Get-WebApplication -Site "Default Web Site" | ?{$_.ApplicationPool -eq "DefaultApppool"}
if($defaultSites.Count -ge 2)
{
    Write-Host "Cafe is running in consolidated state"
    $defaultSites | %{ Write-host "Reverting: $($_.Path)"}
    ConfigureApppool
}
else
{
    Write-host "Cafe is not running consolidated state, no-op"
}
