###############################################################################
# This script handles OWA/ECP updates.
###############################################################################

trap {
	Log ("Error updating OWA/ECP: " + $_)
	Exit
}

$WarningPreference = 'SilentlyContinue'
$ConfirmPreference = 'None'

$script:logDir = "$env:SYSTEMDRIVE\ExchangeSetupLogs"

# Log( $entry )
#	Append a string to a well known text file with a time stamp
# Params:
#	Args[0] - Entry to write to log
# Returns:
#	void
function Log
{
	$entry = $Args[0]

	$line = "[{0}] {1}" -F $(get-date).ToString("HH:mm:ss"), $entry
	write-output($line)
	add-content -Path "$logDir\UpdateCas.log" -Value $line
}

# If log file folder doesn't exist, create it
if (!(Test-Path $logDir)){
	New-Item $logDir -type directory	
}

# Load the Exchange PS snap-in
add-PSSnapin -Name Microsoft.Exchange.Management.PowerShell.SnapIn

Log "***********************************************"
Log ("* UpdateCas.ps1: {0}" -F $(get-date))

# If Mailbox isn't installed on this server, exit without doing anything
if ((Get-ExchangeServer $([Environment]::MachineName)).ServerRole -notmatch "Mailbox") {
		Log "Warning: Mailbox role is not installed on server $([Environment]::MachineName)"
}
Log "Updating OWA/ECP on server $([Environment]::MachineName)"

# get the path to \owa on the filesystem
Log "Finding ClientAccess role install path on the filesystem"
$caspath = (get-itemproperty HKLM:\SOFTWARE\Microsoft\ExchangeServer\v15\Setup).MsiInstallPath + "ClientAccess\"

# GetVersionFromDll
#	Gets the version information from a specified dll
#	appName - the friendly name of the web application
#	webApp  - the alias of the web application, should be the folder name of the physical path
#	dllName  - the name of the assembly that indicate the version of the web application (version folder)
# Returns:
#	String value of the version information on the specified dll.
function GetVersionFromDll($appName, $webApp, $dllName)
{
	$apppath = $caspath + $webApp + "\"
	$dllpath = $apppath + "bin\" + $dllName
	# figure out which version of web application (OWA/ECP) we are moving to
	if (! (test-path ($dllpath))) {
		Log "Could not find '${dllpath}'.  Aborting."
		return $null
	}
	$version = ([diagnostics.fileversioninfo]::getversioninfo($dllpath)).fileversion -replace '0*(\d+)','$1'
	return $version
}

# UpdateWebApp
#	Update a web application in current CAS server.
# Params:
#	appName - the friendly name of the web application
#	webApp  - the alias of the web application, should be the folder name of the physical path
#	version - The version to use. 
#	sourceFolder - The name of the webApp folder to copy files from
#			e.g.: "Current2" for OWA2, "Current" is used for OWA Basic, ECP.
#	destinationFolder - The optional name of the folder to copy to
# Returns:
#	void
# For example, UpdateWebApp "OWA" "owa" "15.0.815" "Current" "prem"
function UpdateWebApp($appName, $webApp, $version, $sourceFolder, $destinationFolder)
{
	if ($version -eq $null) {
		Log "Could not determine version. Aborting."
		return
	}

	$apppath = $caspath + $webApp + "\"
	Log "Updating ${appName} to version $version"

	# filesystem path to the new version directory
	if ($destinationFolder -eq $null){
		$versionpath = $apppath + $version
	}
	else {
		$versionpath = $apppath + $destinationFolder + "\" + $version
	}

	Log "Copying files from '${apppath}${sourceFolder}' to '$versionpath'"
    New-Item $versionpath -Type Directory -ErrorAction SilentlyContinue
	copy-item -recurse -force ($apppath + $sourceFolder + "\*") $versionpath
	
	Log "Update ${appName} done."
}

# Upgrade from CU5 to CU6 leaves some files missing from unversioned OWA folder
# that is updated & replicated during MSP updates
function FixUnversionedFolderAfterUpgrade
{
	try
	{
		$setupRegistry = Get-Item -Path HKLM:\Software\Microsoft\ExchangeServer\v15\Setup\ -ea SilentlyContinue
		if (!$setupRegistry) { Log "FixUnversionedFolderAfterUpgrade: No setupRegistry"; return }

		# C:\Program Files\Microsoft\Exchange Server\V15\ClientAccess
		$installPath = $setupRegistry.GetValue('MsiInstallPath')
		if (!$installPath) { Log "FixUnversionedFolderAfterUpgrade: No installPath"; return }

		# 15.0.995.32
		$installedFork = (@('MsiProductMajor','MsiProductMinor','MsiBuildMajor') | %{ $setupRegistry.GetValue($_) }) -join '.'
		$srcVersions = @((get-item "$installPath\ClientAccess\Owa\prem\$($installedFork).*").Name | Sort { [System.Version] $_ })
		if (!$srcVersions) { Log "FixUnversionedFolderAfterUpgrade: No srcVersions $($installedFork).*"; return }
		Log "FixUnversionedFolderAfterUpgrade: Found source versions: $srcVersions"

		$srcRoot = (Get-Item "$installPath\ClientAccess\Owa\prem\$($srcVersions[0])").FullName
		$destRoot = (Get-Item "$installPath\ClientAccess\Owa\Current2\version").FullName
		Log "FixUnversionedFolderAfterUpgrade: Recovering files from '$srcRoot' to '$destRoot' where necessary"
		foreach ($srcPath in (Get-ChildItem -File -Recurse $srcRoot).FullName)
		{
			$subPath = $srcPath.Substring($srcRoot.Length+1)
			$destPath = "$destRoot\$subPath"
			if (!(Get-Item $destPath -ea SilentlyContinue))
			{
				Log "Copy-Item '$srcPath' '$destPath'"
				$destParent = Split-Path $destPath
				if ($destParent -and !(Test-Path $destParent))
				{
					$null = New-Item $destParent -type Directory
				}
				Copy-Item -Force $srcPath $destPath
			}
		}
		Log "FixUnversionedFolderAfterUpgrade success"
	}
	catch
	{
		Log "FixUnversionedFolderAfterUpgrade failed: $_.Exception.Message"
	}
}
FixUnversionedFolderAfterUpgrade

# Add an attribute to a given XML Element
# <param name="xmlDocument">Document where the attribute will be added</param>
# <param name="xmlElement">Element where the attribute will be added</param>
# <param name="attributeName">Name of the attribute</param>
# <param name="attributeValue">Value of the attribute</param>
function AddXmlAttribute
{
    param ([System.Xml.XmlDocument] $xmlDocument, [System.Xml.XmlElement] $xmlElement, [string] $attributeName, [string] $attributeValue);


    $attribute = $xmlDocument.CreateAttribute($attributeName);
    $attribute.set_Value($attributeValue) | Out-Null
    $xmlElement.SetAttributeNode($attribute) | Out-Null
}

# Add an assembly to the owa web.config.
# <param name="xmlDocument">The xml document to work on.</param>
# <param name="assemblyName">The assembly name to add.</param>
# <param name="version">The version of the assembly.</param>
function AddOrUpdateOwaWebConfigAssembly($xmlDocument, $assemblyName, $version)
{
    $assembliesXPath = "configuration//system.web/compilation/assemblies"
    $assembliesXmlNode = $xmlDocument.SelectSingleNode($assembliesXPath);

    if ($assembliesXmlNode -eq $null) { Log "$assembliesXPath is not found in web.config"; return }

    $addXPath = $assembliesXPath + "/add[starts-with(@assembly, '" + $assemblyName + "')]";
    $addXmlNode = $xmlDocument.SelectSingleNode($addXPath);

    $attributeValue =
            if ($version -ne $null) {
                "$assemblyName,Version=$version,Culture=neutral,publicKeyToken=31bf3856ad364e35";
            }
            else
            {
                "$assemblyName,Culture=neutral,publicKeyToken=31bf3856ad364e35";
            }
    
    # Checks if the <add> node for this assembly already exists, if not create one.
    if ($addXmlNode -eq $null)
    {
       [System.Xml.XmlNode] $addXmlNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "add", $null);

        AddXmlAttribute $xmlDocument $addXmlNode "assembly" $attributeValue;
        $assembliesXmlNode.AppendChild($addXmlNode) | Out-Null
    }
	else
    {
		$addXmlNode.Attributes.RemoveNamedItem("assembly") | Out-Null
        AddXmlAttribute $xmlDocument $addXmlNode "assembly" $attributeValue;
    }
}

# UpdateOwaWebConfig
#   Update Owa's web.config file
function UpdateOwaWebConfig {
	$owaWebConfigFolder = $caspath  + "owa\"
    $owaWebConfigPath = $owaWebConfigFolder + "web.config"

	try {
		$xmlDocument = New-Object System.Xml.XmlDocument;
		$xmlDocument.Load($owaWebConfigPath);

		AddOrUpdateOwaWebConfigAssembly $xmlDocument "Microsoft.Exchange.VariantConfiguration.Core" "15.0.0.0"
		AddOrUpdateOwaWebConfigAssembly $xmlDocument "Microsoft.Search.Platform.Parallax" "3.3.0.0"
		AddOrUpdateOwaWebConfigAssembly $xmlDocument "Microsoft.Exchange.Clients.Owa2.ServerVariantConfiguration" "15.0.0.0"
		AddOrUpdateOwaWebConfigAssembly $xmlDocument "Microsoft.Exchange.VariantConfiguration.ExCore" "15.0.0.0"

		$xmlDocument.Save($owaWebConfigPath) | Out-Null
	}
	catch
	{
		Log "Error loading OWA web.config: $_.Exception.Message"
	}
}

# Update/Add an appsetting key to the owa web.config
# <param name="keyName">The key appsetting key.</param>
# <param name="newValue">The value of the appsetting key.</param>
function UpdateOwaWebConfigAppSettings($keyName, $newValue)
{
	$appSettingNodeName = "configuration//appSettings"
	$owaWebConfigFolder = $caspath  + "owa\"
    $owaWebConfigPath = $owaWebConfigFolder + "web.config"
		
	$owaWebConfigPathCheck = (Get-Item $owaWebConfigPath).FullName
	if (!$owaWebConfigPathCheck) { Log "no OWA web.config is found"; return }

    $xmlDocument = New-Object System.Xml.XmlDocument;
    $xmlDocument.Load($owaWebConfigPath);
    $xmlNode = $xmlDocument.SelectSingleNode($appSettingNodeName);
	
	if ($xmlNode -eq $null) { Log "$appSettingNodeName is not found in web.config"; return }

	$addAsNewAppSettingKey = $true
	foreach ($child in $xmlNode.ChildNodes) 
	{
		if ($child.key -eq $keyName)
		{
			Log "Updating $keyName binding redirect to $newValue"
			$child.value = $newValue
			$xmlDocument.Save($owaWebConfigPath) | Out-Null
			$addAsNewAppSettingKey = $false
            break
		}
	}

	if ($addAsNewAppSettingKey)
	{
		Log "Adding $keyName appSetting with value $newValue"
		[System.Xml.XmlNode] $addXmlNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "add", $null);
		AddXmlAttribute $xmlDocument $addXmlNode "key" $keyName;
		AddXmlAttribute $xmlDocument $addXmlNode "value" $newValue;
		$xmlNode.AppendChild($addXmlNode) | Out-Null
		$xmlDocument.Save($owaWebConfigPath) | Out-Null
	}
}

UpdateOwaWebConfigAppSettings "owin:AutomaticAppStartup" "true"

# Add HttpHandler to the web.config
# <param name="xmlDocument">Name of the assembly: eg: Microsoft.Live.Controls</param>
# <param name="verb">verb</param>
# <param name="path">path</param>
# <param name="type">type</param>
# <param name="name">name</param>
# <param name="preCondition">preCondition</param>
function AddHttpHandlerToWebConfig
{
    param ([System.Xml.XmlDocument] $xmlDocument, [string] $verb, [string] $path, [string] $type, [string] $name, [string] $preCondition = "managedHandler" );

    # <configuration>
    #   <location inheritInChildApplications="false">
    #     <system.webServer>
    #       <handlers>

    $handlersNode = $xmlDocument.SelectSingleNode("configuration/location/system.webServer/handlers");

    # if handlersNode is null, fail
    if ($handlersNode -eq $null)
    {
        Log "Web.config file does notr have handlers section: $key";
        return;
    }

    # now check if we already have added the HttpHandler node
    $httpHandlerNode = $xmlDocument.SelectSingleNode("/configuration/location/system.webServer/handlers/add[@path='$path']");

    # create the HttpHandler node if it doesn't already exist, else ignore it
    if ($httpHandlerNode -eq $null)
    {
        #
        # Create httpHandlerNode
        #
        $httpHandlerNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "add", $null);

        # TODO: we are assuming that this returns the child node we just appended
        $httpHandlerNode  = $handlersNode.AppendChild($httpHandlerNode);

        #
        # Add attributes
        #
        AddXmlAttribute $xmlDocument $httpHandlerNode "verb" $verb;
        AddXmlAttribute $xmlDocument $httpHandlerNode "path" $path;
        AddXmlAttribute $xmlDocument $httpHandlerNode "type" $type;
        AddXmlAttribute $xmlDocument $httpHandlerNode "name" $name;
        AddXmlAttribute $xmlDocument $httpHandlerNode "preCondition" $preCondition;
    }
    else
    {
        Log "Web.config file already had a node for: $path";
    }
}

# Add/Update managed handler to owa web.config
function UpdateOwaWebConfigHandlers
{
    $owaWebConfigFolder = $caspath  + "owa\";
    $owaWebConfigPath = $owaWebConfigFolder + "web.config";
    $owaWebConfigPathCheck = (Get-Item $owaWebConfigPath).FullName;

    if (!$owaWebConfigPathCheck) 
    {
        Log "no OWA web.config is found"; 
        return;
    }

    $xmlDocument = New-Object System.Xml.XmlDocument;
    $xmlDocument.Load($owaWebConfigPath);

    AddHttpHandlerToWebConfig $xmlDocument "POST,GET" "userbootsettings.ashx" "Microsoft.Exchange.Clients.Owa2.Server.Web.UserBootSettingsHandler, Microsoft.Exchange.Clients.Owa2.Server" "UserBootSettingsHandler"
    AddHttpHandlerToWebConfig $xmlDocument "GET" "MeetingPollHandler.ashx" "Microsoft.Exchange.Clients.Owa2.Server.Web.MeetingPollHandler, Microsoft.Exchange.Clients.Owa2.Server" "MeetingPollHandler"

    $xmlDocument.Save($owaWebConfigPath) | Out-Null
}

Log "Updating owa handlers";
UpdateOwaWebConfigHandlers

#  Update/Add an  assembly binding redirect to the owa web.config.
# <param name="assemblyName">The assembly name to add.</param>
# <param name="publicKeyToken">The assembly public key token.</param>
# <param name="oldVersion">The oldVersion of the binding redirect.</param>
# <param name="newVersion">The newVersion of the binding redirect.</param>
function UpdateOwaWebConfigBindingRedirect($assemblyName, $publicKeyToken, $oldVersion, $newVersion) 
{
	$assemblyBindingNodeName = "configuration/runtime/ns:assemblyBinding"
	$owaWebConfigFolder = $caspath  + "owa\"
    $owaWebConfigPath = $owaWebConfigFolder + "web.config"
		
	$owaWebConfigPathCheck = (Get-Item $owaWebConfigPath).FullName
	if (!$owaWebConfigPathCheck) { Log "no OWA web.config is found"; return }

    $xmlDocument = New-Object System.Xml.XmlDocument;
    $xmlDocument.Load($owaWebConfigPath);
    $nsm = New-Object System.Xml.XmlNamespaceManager $xmlDocument.NameTable
    $nsm.AddNamespace("ns", "urn:schemas-microsoft-com:asm.v1")
    $xmlNode = $xmlDocument.SelectSingleNode($assemblyBindingNodeName, $nsm);
    
    if ($xmlNode -eq $null) { Log "$assemblyBindingNodeName is not found in web.config"; return }

	$addAsNewBindingRedirect = $true 
	foreach ($dependentAssembly in $xmlNode.ChildNodes) 
	{
		$assemblyIdentity = $null
        $bindingRedirect = $null
		foreach ($child in $dependentAssembly.ChildNodes)
		{
			if ($child.LocalName -eq "assemblyIdentity")
            {
                $assemblyIdentity = $child 
            }
            elseif ($child.LocalName -eq "bindingRedirect")
            {
                $bindingRedirect = $child 
            }
		}

		if ($assemblyIdentity -ne $null -and $assemblyIdentity.Name -eq $assemblyName -and $assemblyIdentity.publicKeyToken -eq $publicKeyToken -and $bindingRedirect -ne $null)
        {
			Log "Updating $assemblyName binding redirect"
            $bindingRedirect.oldVersion = $oldVersion
            $bindingRedirect.newVersion = $newVersion
            $xmlDocument.Save($owaWebConfigPath) | Out-Null
			$addAsNewBindingRedirect = $false
            break
        }
	}

	if ($addAsNewBindingRedirect)
	{
		Log "Adding $assemblyName binding redirect"
		[System.Xml.XmlNode] $dependentAssemblyXmlNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "dependentAssembly", "urn:schemas-microsoft-com:asm.v1");
		[System.Xml.XmlNode] $assemblyIdentityXmlNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "assemblyIdentity", "urn:schemas-microsoft-com:asm.v1");
		[System.Xml.XmlNode] $bindingRedirectXmlNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "bindingRedirect", "urn:schemas-microsoft-com:asm.v1");

        AddXmlAttribute $xmlDocument $assemblyIdentityXmlNode "name" $assemblyName;
		AddXmlAttribute $xmlDocument $assemblyIdentityXmlNode "publicKeyToken" $publicKeyToken;
		AddXmlAttribute $xmlDocument $assemblyIdentityXmlNode "culture" "neutral";

		AddXmlAttribute $xmlDocument $bindingRedirectXmlNode "oldVersion" $oldVersion;
		AddXmlAttribute $xmlDocument $bindingRedirectXmlNode "newVersion" $newVersion;

        $xmlNode.AppendChild($dependentAssemblyXmlNode) | Out-Null
		$dependentAssemblyXmlNode.AppendChild($assemblyIdentityXmlNode) | Out-Null
		$dependentAssemblyXmlNode.AppendChild($bindingRedirectXmlNode) | Out-Null
		$xmlDocument.Save($owaWebConfigPath) | Out-Null
	}
}

# Enable the EnableClientsCommonModule
function EnableClientsCommonModule
{
	$owaWebConfigFolder = $caspath  + "owa\"
    $owaWebConfigPath = $owaWebConfigFolder + "web.config"
		
	$owaWebConfigPathCheck = (Get-Item $owaWebConfigPath).FullName
	if (!$owaWebConfigPathCheck) { Log "no OWA web.config is found"; return }

    $xmlDocument = New-Object System.Xml.XmlDocument;
    $xmlDocument.Load($owaWebConfigPath);
    
    $configurationRoot = "configuration/location";

    $clientsCommonModuleNode = $xmlDocument.SelectSingleNode($configurationRoot + "/system.webServer/modules/add[@name='ClientsCommonModule']");

    $clientsCommonModuleNodeType = "Microsoft.Exchange.Clients.Common.ClientsCommonModule";

    if ($clientsCommonModuleNode -eq $null)
    {
        Log "Adding clients common module to Web.config file" "Warning";
        [System.Xml.XmlNode] $clientsCommonModuleNode = $xmlDocument.CreateNode([System.Xml.XmlNodeType]::Element, "add", $null);

        AddXmlAttribute $xmlDocument $clientsCommonModuleNode "name" "ClientsCommonModule";
        AddXmlAttribute $xmlDocument $clientsCommonModuleNode "type" $clientsCommonModuleNodeType;

        $modulesNode = $xmlDocument.SelectSingleNode($configurationRoot + "/system.webServer/modules");
        $owa2ModuleNode = $xmlDocument.SelectSingleNode($configurationRoot + "/system.webServer/modules/add[@name='Owa2Module']");

        $modulesNode.InsertBefore($clientsCommonModuleNode, $owa2ModuleNode);
        $xmlDocument.Save($owaWebConfigPath) | Out-Null
    }
}

UpdateOwaWebConfigBindingRedirect "Microsoft.Owin" "31bf3856ad364e35" "0.0.0.0-2.1.0.0" "3.0.1.0"
UpdateOwaWebConfigBindingRedirect "Microsoft.Owin.Security" "31bf3856ad364e35" "0.0.0.0-2.1.0.0" "3.0.1.0"
EnableClientsCommonModule

# Update OWA
$owaBasicVersion = (get-itemproperty -Path HKLM:\Software\Microsoft\ExchangeServer\v15\Setup\ -Name "OwaBasicVersion" -ea SilentlyContinue).OwaBasicVersion
$owaVersion = (get-itemproperty -Path HKLM:\Software\Microsoft\ExchangeServer\v15\Setup\ -Name "OwaVersion" -ea SilentlyContinue).OwaVersion

UpdateWebApp "OWA" "owa" $owaBasicVersion "Current" $null
UpdateWebApp "OWA" "owa" $owaVersion "Current2\version" "prem"
UpdateOwaWebConfig

# Update ECP
# Anonymous access has been enabled on ECP root folder by default, so it isn't necessary to enable anonymous access on the version folder explicitly
$ecpVersion = GetVersionFromDll "ECP" "ecp" "Microsoft.Exchange.Management.ControlPanel.dll"
UpdateWebApp "ECP" "ecp" $ecpVersion "Current" $null

# Remove the Exchange PS snap-in
remove-PSSnapin -Name Microsoft.Exchange.Management.PowerShell.SnapIn
